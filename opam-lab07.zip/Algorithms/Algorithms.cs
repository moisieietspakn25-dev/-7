using System;
using System.Collections.Generic;

namespace OpamLab07;

public static class Algorithms
{
    // Відбір: один алгоритм для будь-якого типу елементів.
    public static List<T> Filter<T>(List<T> src, Func<T, bool> keep)
    {
        ArgumentNullException.ThrowIfNull(src);
        ArgumentNullException.ThrowIfNull(keep);

        var result = new List<T>();
        foreach (T item in src)
            if (keep(item))
                result.Add(item);

        return result;
    }

    // Перетворення: тип вхідного та вихідного елементів може відрізнятися.
    public static List<TOut> Map<TIn, TOut>(List<TIn> src, Func<TIn, TOut> convert)
    {
        ArgumentNullException.ThrowIfNull(src);
        ArgumentNullException.ThrowIfNull(convert);

        var result = new List<TOut>();
        foreach (TIn item in src)
            result.Add(convert(item));

        return result;
    }

    // Агрегація: start — початковий стан, step — функція оновлення стану.
    public static TAcc Aggregate<T, TAcc>(
        List<T> src, TAcc start, Func<TAcc, T, TAcc> step)
    {
        ArgumentNullException.ThrowIfNull(src);
        ArgumentNullException.ThrowIfNull(step);

        TAcc acc = start;
        foreach (T item in src)
            acc = step(acc, item);

        return acc;
    }

    // Групування за ключем, який надає викликач.
    public static Dictionary<TKey, List<T>> GroupBy<T, TKey>(
        List<T> src, Func<T, TKey> keyOf) where TKey : notnull
    {
        ArgumentNullException.ThrowIfNull(src);
        ArgumentNullException.ThrowIfNull(keyOf);

        var result = new Dictionary<TKey, List<T>>();
        foreach (T item in src)
        {
            TKey key = keyOf(item);
            if (!result.TryGetValue(key, out List<T>? group))
            {
                group = new List<T>();
                result.Add(key, group);
            }
            group.Add(item);
        }

        return result;
    }
}
