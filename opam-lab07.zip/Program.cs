using System;
using System.Collections.Generic;
using OpamLab07;

const int N = 17;
const int K = 20;
const int A = 2;
const int B = 1;
const int C = 2;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.WriteLine($"N = {N}, K = {K}, a = {A}, b = {B}, c = {C}");
Console.WriteLine("Лабораторна робота №7 — узагальнені алгоритми\n");

// Набір 1. За умовою генератор має бути new Random(N).
var random = new Random(N);
var numbers = new List<int>();
for (int i = 0; i < 20; i++)
    numbers.Add(random.Next(-K, K + 1));

var words = new List<string>
{
    "кіт", "програмування", "веб-сайт", "алгоритм", "CSharp",
    "сонце", "комп'ютер", "будь-який", "книга", "узагальнення",
    "рядок", "дані", "студент", "синьо-жовтий"
};

// Прикладові дані для Student. Якщо у лабораторній №6 уже є власний список,
// заміни цей список на дані з попередньої роботи.
var students = new List<Student>
{
    new("Мойсєєць Павло", "КН-3/1", 92),
    new("Іваненко Олена", "КН-3/1", 78),
    new("Петренко Андрій", "КН-3/2", 64),
    new("Шевченко Марія", "КН-2/1", 55),
    new("Коваль Ігор", "КН-3/1", 87),
    new("Бондар Софія", "КН-2/2", 73),
    new("Мельник Денис", "КН-3/2", 45),
    new("Ткачук Анна", "КН-3/1", 60),
    new("Романюк Олег", "КН-2/1", 100),
    new("Лисенко Юлія", "КН-3/2", 89),
    new("Кравець Назар", "КН-2/2", 32),
    new("Олійник Дарина", "КН-3/1", 75)
};

Console.WriteLine("=== Набори даних ===");
Console.WriteLine("Числа: " + string.Join(", ", numbers));
Console.WriteLine("Рядки: " + string.Join(", ", words));
Console.WriteLine("Студенти: " + students.Count);

// Завдання 1. Filter: a = 2.
Console.WriteLine("\n=== Завдання 1. Filter ===");
var filteredNumbers = Algorithms.Filter(numbers, x => x <= 0);
var filteredWords = Algorithms.Filter(words, s => s.Contains('-'));
var filteredStudents = Algorithms.Filter(students, s => s.Score >= 60 && s.Score <= 89);
PrintList("Числа <= 0", filteredNumbers);
PrintList("Рядки з дефісом", filteredWords);
PrintList("Студенти з балом 60..89", filteredStudents);
Console.WriteLine("Тіло Filter змінювалося між застосуваннями: 0 разів.");

// Завдання 2. Map: b = 1.
Console.WriteLine("\n=== Завдання 2. Map ===");
int divisor = K % 7 + 2; // 20 % 7 + 2 = 8
var mappedNumbers = Algorithms.Map(numbers, x => ((x % divisor) + divisor) % divisor);
var mappedWords = Algorithms.Map(words, s => s.ToUpperInvariant());
var mappedStudents = Algorithms.Map(students, s => s.Surname);
PrintList($"Числа -> остача за модулем {divisor}", mappedNumbers);
PrintList("Рядки -> верхній регістр", mappedWords);
PrintList("Студенти -> прізвище", mappedStudents);

// Завдання 3. Aggregate: три агрегації чисел і конкатенація рядків (c = 2).
Console.WriteLine("\n=== Завдання 3. Aggregate ===");
long sum = Algorithms.Aggregate(numbers, 0L, (acc, x) => acc + x);
long product = Algorithms.Aggregate(numbers, 1L, (acc, x) => acc * x);
if (numbers.Count == 0)
    Console.WriteLine("Максимум: список порожній, максимум не визначений.");
else
{
    int maximum = Algorithms.Aggregate(numbers, int.MinValue, (acc, x) => x > acc ? x : acc);
    Console.WriteLine($"Максимум: {maximum}");
}
Console.WriteLine($"Сума: {sum}");
Console.WriteLine($"Добуток: {product}");
string joinedWords = Algorithms.Aggregate(words, "", (acc, s) =>
    acc.Length == 0 ? s : acc + ", " + s);
Console.WriteLine($"Конкатенація рядків: {joinedWords}");

// Завдання 4. GroupBy.
Console.WriteLine("\n=== Завдання 4. GroupBy ===");
PrintGroups("За групою", Algorithms.GroupBy(students, s => s.Group));
PrintGroups("За першою літерою прізвища",
    Algorithms.GroupBy(students, s => s.Surname.Length == 0 ? '?' : char.ToUpperInvariant(s.Surname[0])));
PrintGroups("За діапазоном балів", Algorithms.GroupBy(students, s =>
    s.Score <= 59 ? "0–59" :
    s.Score <= 74 ? "60–74" :
    s.Score <= 89 ? "75–89" : "90–100"));
PrintGroups("Рядки за довжиною", Algorithms.GroupBy(words, s => s.Length));

// Завдання 5. Захоплення змінних.
Console.WriteLine("\n=== Завдання 5. Захоплення змінних ===");

// 5.1 Лямбда захоплює змінну, а не її поточне значення.
int threshold = K;
Func<int, bool> aboveThreshold = x => x > threshold;
threshold = 1000;
Console.WriteLine($"1) Поріг після зміни = {threshold}; перевірка 50 > поріг: {aboveThreshold(50)}");

// 5.2 У for всі лямбди захоплюють одну змінну i.
var forFunctions = new List<Func<int>>();
for (int i = 0; i < 3; i++)
    forFunctions.Add(() => i);
Console.WriteLine("2) for: " + string.Join(", ", Algorithms.Map(forFunctions, f => f())));

// 5.3 У сучасному C# кожна ітерація foreach має власну змінну ітерації.
var foreachFunctions = new List<Func<int>>();
foreach (int item in new[] { 0, 1, 2 })
    foreachFunctions.Add(() => item);
Console.WriteLine("3) foreach: " + string.Join(", ", Algorithms.Map(foreachFunctions, f => f())));

Console.WriteLine("Виправлення for: створювати локальну копію i всередині циклу й захоплювати її.");

// Завдання 6 — відповіді наведено в README.md.
Console.WriteLine("\nВисновок: алгоритми працюють із різними типами завдяки параметрам типу та делегатам.");

static void PrintList<T>(string title, List<T> items)
{
    Console.WriteLine($"{title} ({items.Count}): {string.Join(", ", items)}");
}

static void PrintGroups<TKey, T>(string title, Dictionary<TKey, List<T>> groups) where TKey : notnull
{
    Console.WriteLine(title + ":");
    foreach (var pair in groups)
        Console.WriteLine($"  {pair.Key}: {pair.Value.Count}");
}
