namespace OpamLab07;

public sealed class Student
{
    public string Name { get; set; }
    public string Group { get; set; }
    public int Score { get; set; }

    public Student(string name, string group, int score)
    {
        Name = name;
        Group = group;
        Score = score;
    }

    // У Name зберігається повне ім'я; перше слово вважаємо прізвищем.
    public string Surname
    {
        get
        {
            string trimmed = Name.Trim();
            int space = trimmed.IndexOf(' ');
            return space < 0 ? trimmed : trimmed[..space];
        }
    }

    public override string ToString() => $"{Name} ({Group}, {Score})";
}
